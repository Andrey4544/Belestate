import { Property, BlogPost } from '../types';

export const properties: Property[] = [
  {
    "id": 1,
    "titleBg": "Дава под наем 2-СТАЕН, град Пловдив, Южен",
    "titleEn": "For Rent: 2-Room Apartment",
    "descriptionBg": "50 кв.м, 3-ти ет. от 5, Предлагаме ви , двустаен апартамент в монолитна сгада , намираща се в пресечка на бул.Ал.Стамболийск ...,",
    "descriptionEn": "We are pleased to introduce this property listed for rent in Plovdiv, Yuzhen Suburb, Plovdiv. The property spans a total of 50 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 300,
    "currency": "EUR",
    "locationBg": "град Пловдив, Южен",
    "locationEn": "Plovdiv, Yuzhen Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 50,
    "rooms": 2,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/2/787/2c177911164611787_Yw.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/2/787/2c177911164611787_Yw.jpg",
      "https://cdn3.focus.bg/imot/photosimotbg/2/787/2c177911164611787_MI.jpg",
      "https://cdn3.focus.bg/imot/photosimotbg/2/787/2c177911164611787_u2.jpg"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 2,
    "titleBg": "Продава ВИЛА, с. Храбрино, област Пловдив",
    "titleEn": "For Sale: Countryside Villa",
    "descriptionBg": "46 кв.м, двор 600 кв.м, Втора Вилна Зона, Въведен в експлоатация, Предлагаме ви за продажба вила във Втора Вилна Зона на с.Храбрино.Имотът е с площ от 600 кв.м.Вилата ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Hrabrino Village, Plovdiv, Plovdiv. The property spans a total of 46 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 79990,
    "currency": "EUR",
    "locationBg": "с. Храбрино, област Пловдив",
    "locationEn": "Hrabrino Village, Plovdiv, Plovdiv",
    "cityKey": "с. Храбрино",
    "typeKey": "villa",
    "sqMeters": 46,
    "rooms": 4,
    "bathrooms": 2,
    "yearBuilt": 2023,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/990/1k178177986770990_1r.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/990/1k178177986770990_1r.jpg"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 3,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Остромила",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "110 кв.м, до Ромпетрол, 5-ти ет. от 6, Въведен в експлоатация 2025 г., Оферта 102.Предлагаме Ви прекрасен тристаен апартамент в нова жилищна сграда, с АКТ 16 , на много ко ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Остромила, Plovdiv. The property spans a total of 110 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 139990,
    "currency": "EUR",
    "locationBg": "град Пловдив, Остромила",
    "locationEn": "Plovdiv, Остромила, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 110,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2025,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/387/1c174161964187387_n7.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/387/1c174161964187387_n7.jpg"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 4,
    "titleBg": "Продава 2-СТАЕН, град Пловдив, Кючук Париж",
    "titleEn": "For Sale: 2-Room Apartment",
    "descriptionBg": "64 кв.м, ул.Студенец, 4-ти ет. от 4, Въведен в експлоатация 1997 г., оферта номер:104 Предлагаме Ви много функционално,светло жилище ,с прекрасна локация в квартала,в бл ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Кючук Париж, Plovdiv. The property spans a total of 64 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 87990,
    "currency": "EUR",
    "locationBg": "град Пловдив, Кючук Париж",
    "locationEn": "Plovdiv, Кючук Париж, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 64,
    "rooms": 2,
    "bathrooms": 1,
    "yearBuilt": 1997,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/864/1b173883582476864_X5.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/864/1b173883582476864_X5.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 5,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "750 кв.м, между Марково и Първенец, Регулация, предлагаме ви 2 парцела със сменен статут за жилищно строителство на 200 м.от асфалтовия път между М ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 750 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 56250,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 750,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 6,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "852 кв.м, Регулация, Предлагаме ви парцел с прекрасен достъп срещу Хотел Марково.Имота е с променен статут за жил.строите ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 852 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 99990,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 852,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 7,
    "titleBg": "Продава ПАРЦЕЛ, град Пловдив, Индустриална зона - Юг",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "2505 кв.м, Асеновградско шосе, Оферта141. Предлагаме ви уникален инвестиционен имот , с 45м лице на главния асфалтов път свързващ г ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Industrial Zone - South, Plovdiv. The property spans a total of 2505 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 147795,
    "currency": "EUR",
    "locationBg": "град Пловдив, Индустриална зона - Юг",
    "locationEn": "Plovdiv, Industrial Zone - South, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 2505,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/611/1r177919726774611_Tt.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/611/1r177919726774611_Tt.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 8,
    "titleBg": "Продава ПАРЦЕЛ, с. Храбрино, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1004 кв.м, пътя за Извор, Регулация, Оферта 124.Предлагаме ви парцел със сменен статут за жилищно строителство с лице на асфалтовия път о ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Hrabrino Village, Plovdiv, Plovdiv. The property spans a total of 1004 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 49900,
    "currency": "EUR",
    "locationBg": "с. Храбрино, област Пловдив",
    "locationEn": "Hrabrino Village, Plovdiv, Plovdiv",
    "cityKey": "с. Храбрино",
    "typeKey": "land",
    "sqMeters": 1004,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/1/982/1r167766331688982_WM.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/1/982/1r167766331688982_WM.jpg"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 9,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "2498 кв.м, Регулация, Предлагаме ви парцел със сменен статут за промишлено строителство.Намира се на 200м. от асфалтов път ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 2498 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 159872,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 2498,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 10,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "700 кв.м, между Марково и Първенец, Оферта 115.Предлагаме ви парцел между Марково и Първенец от долната страна на 200м. от асфалтовия пъ ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 700 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 31500,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 700,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 11,
    "titleBg": "Продава ПАРЦЕЛ, град Пловдив, Пещерско шосе",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "4037 кв.м, пътя за Оризари, Регулация, Предлагаме ви парцел за производствен и складов обект на 500м.от табелата на Пловдив посока с.Оризар ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Пещерско шосе, Plovdiv. The property spans a total of 4037 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 217998,
    "currency": "EUR",
    "locationBg": "град Пловдив, Пещерско шосе",
    "locationEn": "Plovdiv, Пещерско шосе, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 4037,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 12,
    "titleBg": "Продава ПАРЦЕЛ, град Пловдив, Беломорски",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "3000 кв.м, Регулация, Ток, Вода, оферта 230.Предлагаме Ви парцел-УПИ за жилищно строителство в непосредствена близост до къщи,всички ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Беломорски, Plovdiv. The property spans a total of 3000 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 720000,
    "currency": "EUR",
    "locationBg": "град Пловдив, Беломорски",
    "locationEn": "Plovdiv, Беломорски, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 3000,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/685/1r174176915414685_sO.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/685/1r174176915414685_sO.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 13,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "643 кв.м, м.Комсала, Регулация, Предлагаме ви 2 бр.парцели за жилищно строителство с лице на асфалтовия път за Борсата на с.Първенец ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 643 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 50797,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 643,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/724/1r175758790104724_v.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/724/1r175758790104724_v.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 14,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "2730 кв.м, м.Герена, Регулация, Предлагаме ви парцел в процедура на смяна на статута за промишлено строителство в м.Герена в близост ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 2730 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 122850,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 2730,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 15,
    "titleBg": "Продава ПАРЦЕЛ, с. Брестник, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "891 кв.м, Оферта 221.ПРОДАВА СЕ 891кв.м.За повече информация и огледи 0897913101,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Брестник, Plovdiv, Plovdiv. The property spans a total of 891 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 16038,
    "currency": "EUR",
    "locationBg": "с. Брестник, област Пловдив",
    "locationEn": "с. Брестник, Plovdiv, Plovdiv",
    "cityKey": "с. Брестник",
    "typeKey": "land",
    "sqMeters": 891,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/1/164/1r169528024931164_Hh.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/1/164/1r169528024931164_Hh.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 16,
    "titleBg": "Продава ПАРЦЕЛ, с. Брестник, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "960 кв.м, Регулация, Оферта 229.Предлагаме Ви три броя урегулирани поземлени имота с чиста площ от 845кв.м и прилежащ път ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Брестник, Plovdiv, Plovdiv. The property spans a total of 960 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 52800,
    "currency": "EUR",
    "locationBg": "с. Брестник, област Пловдив",
    "locationEn": "с. Брестник, Plovdiv, Plovdiv",
    "cityKey": "с. Брестник",
    "typeKey": "land",
    "sqMeters": 960,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 17,
    "titleBg": "Продава ПАРЦЕЛ, с. Цалапица, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "7220 кв.м, оферта 248.Предлагаме Ви земеделска земя,нива,категория 5,в землището на с.Цалапица,с лице на автома ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Цалапица, Plovdiv, Plovdiv. The property spans a total of 7220 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 68800,
    "currency": "EUR",
    "locationBg": "с. Цалапица, област Пловдив",
    "locationEn": "с. Цалапица, Plovdiv, Plovdiv",
    "cityKey": "с. Цалапица",
    "typeKey": "land",
    "sqMeters": 7220,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/1/692/1r171083949235692_x6.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/1/692/1r171083949235692_x6.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 18,
    "titleBg": "Продава ПАРЦЕЛ, магистрала Тракия, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "4100 кв.м, с.Трилистник, оферта 206. Продаваме Ви парцел с лице на автомагистрала Тракия,в землището на с.Трилистник,нива,4 к ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Trakia Suburb, Plovdiv, Plovdiv. The property spans a total of 4100 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 61500,
    "currency": "EUR",
    "locationBg": "магистрала Тракия, област Пловдив",
    "locationEn": "Trakia Suburb, Plovdiv, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 4100,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 19,
    "titleBg": "Продава ПАРЦЕЛ, с. Брестовица, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1425 кв.м, Регулация, Ток, Вода, Оферта 125.Предлагаме ви отличен парцел, в регулацията на селото, за жилищно застрояване, с много до ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Брестовица, Plovdiv, Plovdiv. The property spans a total of 1425 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 74600,
    "currency": "EUR",
    "locationBg": "с. Брестовица, област Пловдив",
    "locationEn": "с. Брестовица, Plovdiv, Plovdiv",
    "cityKey": "с. Брестовица",
    "typeKey": "land",
    "sqMeters": 1425,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic3.focus.bg/imot/photosimotbg/1/536/1r173435159059536_L0.jpg",
    "gallery": [
      "https://imotstatic3.focus.bg/imot/photosimotbg/1/536/1r173435159059536_L0.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 20,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "2730 кв.м, Институт по Тютюн, Регулация, Предлагаме ви панорамен парцел,до новопостроени къщи в местност Исака.Парцелът е със сменен статут з ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 2730 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 232050,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 2730,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/463/1r175801993842463_VM.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/463/1r175801993842463_VM.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 21,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1026 кв.м, Регулация, Ток, Оферта-135 ПРЕДЛАГАМЕ ВИ ДВА САМОСТОЯТЕЛНИ УРЕГУЛИРАНИ ИМОТА, С ВЪТРЕШЕН ПЪТ В С.ПЪРВЕНЕЦ, В РАЙОН З ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 1026 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 56430,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 1026,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/370/1r171464053999370_4R.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/370/1r171464053999370_4R.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 22,
    "titleBg": "Продава ПАРЦЕЛ, град Пловдив, Коматево",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "500 кв.м, ул.Лозарска, Регулация, Ток, Вода, Предлагаме ви парцел в регулацията на квартала със всички комуникации и между новопостроени къщи.За ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Коматево, Plovdiv. The property spans a total of 500 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 150000,
    "currency": "EUR",
    "locationBg": "град Пловдив, Коматево",
    "locationEn": "Plovdiv, Коматево, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 500,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 23,
    "titleBg": "Продава ПАРЦЕЛ, град Пловдив, Индустриална зона - Изток",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "7500 кв.м, Главния път за гр.Харманл, Оферта139. Предлагаме ви уникален инвестиционен имот с 37м лице на главния асфалтов път за гр.Свиле ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Индустриална зона - Изток, Plovdiv. The property spans a total of 7500 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 0,
    "currency": "EUR",
    "locationBg": "град Пловдив, Индустриална зона - Изток",
    "locationEn": "Plovdiv, Индустриална зона - Изток, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 7500,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/259/1r171592872037259_1t.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/259/1r171592872037259_1t.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 24,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "8818 кв.м, Оферта 402.Парцелът се намира на асфалтовия път между Първенец и Брестовица. Има 180м. лице на асфал ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 8818 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 132270,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 8818,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/912/1r119729685052912_1.pic",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/912/1r119729685052912_1.pic"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 25,
    "titleBg": "Продава ПАРЦЕЛ, град Пловдив, Беломорски",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1420 кв.м, Регулация, Оферта 129.ПРЕДЛАГАМЕ ВИ УЛИГУЛИРАН ИМОТ, В КВ.БЕЛОМОРСКИ. РАЙОНА Е ЗАСТРОЕН С НОВИ КЪЩИ. До имота и ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Беломорски, Plovdiv. The property spans a total of 1420 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 150000,
    "currency": "EUR",
    "locationBg": "град Пловдив, Беломорски",
    "locationEn": "Plovdiv, Беломорски, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 1420,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/652/1r164370731240652_KM.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/652/1r164370731240652_KM.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 26,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "4900 кв.м, оферта209.Предлагаме Ви земеделска земя,четвърта категория-в местност Аптекарово и Метери.Близо до З ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 4900 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 156800,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 4900,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 27,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1004 кв.м, между Марково и Първенец, Регулация, Предлагаме ви парцели 2 бр. по 910 кв.м.с променен статут за жилищно строителство.Намират се между М ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 1004 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 75300,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 1004,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/1/224/1r175801685872224_iC.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/1/224/1r175801685872224_iC.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 28,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "2016 кв.м, Регулация, оферта 240.Предлагаме Ви УПИ в село Първенец,до къщи,на път,с комукации.Площ на парцела 1812кв.м.и 2 ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 2016 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 185000,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 2016,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 29,
    "titleBg": "Продава ПАРЦЕЛ, с. Брестовица, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1800 кв.м, източната част на селото, Регулация, Оферта 118.Предлагаме ви УПИ В източната част на селото с лесен достъп и прекрасна гледка.За повече ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Брестовица, Plovdiv, Plovdiv. The property spans a total of 1800 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 41400,
    "currency": "EUR",
    "locationBg": "с. Брестовица, област Пловдив",
    "locationEn": "с. Брестовица, Plovdiv, Plovdiv",
    "cityKey": "с. Брестовица",
    "typeKey": "land",
    "sqMeters": 1800,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 30,
    "titleBg": "Дава под наем 2-СТАЕН, град Пловдив, Коматево",
    "titleEn": "For Rent: 2-Room Apartment",
    "descriptionBg": "75 кв.м, Стадион Ботев, 2-ри ет. от 5, Предлагаме ви, нов, двустаен, напълно обзаведен , луксозен апартамент, в нова сграда с отлична локац ...,",
    "descriptionEn": "We are pleased to introduce this property listed for rent in Plovdiv, Коматево, Plovdiv. The property spans a total of 75 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 499,
    "currency": "EUR",
    "locationBg": "град Пловдив, Коматево",
    "locationEn": "Plovdiv, Коматево, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 75,
    "rooms": 2,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/2/837/2c178168359971837_X7.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/2/837/2c178168359971837_X7.jpg",
      "https://cdn3.focus.bg/imot/photosimotbg/2/837/2c178168359971837_CF.jpg",
      "https://cdn3.focus.bg/imot/photosimotbg/2/837/2c178168359971837_d8.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 31,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1961 кв.м, Оферта 140.Предлагаме ви зем.земя зад борсата на Първенец с лице на полски път 20м.подходящ за както ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 1961 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 39999,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 1961,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 32,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "4439 кв.м, оферта 202.Предлагаме Ви парцел,подходящ след промяна на предназначението за промилено строителство- ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 4439 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 124292,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 4439,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 33,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "3610 кв.м, спа Хотел Марково, Регулация, Оферта 117.Предлагаме ви панорамен парцел, с променен статут- за складова база. Намира се в района, ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 3610 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 162450,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 3610,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/064/1r166315875524064_FP.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/064/1r166315875524064_FP.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 34,
    "titleBg": "Продава ПАРЦЕЛ, с. Чешнегирово, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "7500 кв.м, Оферта139. Предлагаме ви уникален инвестиционен имот с 37м лице на главния асфалтов път за гр.Свиле ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Чешнегирово, Plovdiv, Plovdiv. The property spans a total of 7500 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 75000,
    "currency": "EUR",
    "locationBg": "с. Чешнегирово, област Пловдив",
    "locationEn": "с. Чешнегирово, Plovdiv, Plovdiv",
    "cityKey": "с. Чешнегирово",
    "typeKey": "land",
    "sqMeters": 7500,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 35,
    "titleBg": "Продава ПАРЦЕЛ, град Пловдив, Прослав",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1452 кв.м, оферта 246.Предлагаме Ви една трета идеални части от атрактивен парцел целия с площ от 4356кв.м.-зем ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Прослав, Plovdiv. The property spans a total of 1452 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 62000,
    "currency": "EUR",
    "locationBg": "град Пловдив, Прослав",
    "locationEn": "Plovdiv, Прослав, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 1452,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/1/809/1r171049734909809_1v.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/1/809/1r171049734909809_1v.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 36,
    "titleBg": "Продава КЪЩА, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Family Home",
    "descriptionBg": "230 кв.м, двор 630 кв.м, 2 ет. от 2, Ще бъде въведен в експлоатация 2026 г., Предлагаме на вашето внимание, нова, модерна, функционална, еднофамилна къща в с. Първенец,на 3 км. ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 230 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 225900,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "house",
    "sqMeters": 230,
    "rooms": 4,
    "bathrooms": 2,
    "yearBuilt": 2026,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/497/1j175638282726497_GE.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/497/1j175638282726497_GE.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 37,
    "titleBg": "Продава КЪЩА, с. Храбрино, област Пловдив",
    "titleEn": "For Sale: Family Home",
    "descriptionBg": "130 кв.м, двор 260 кв.м, център, 2 ет., Въведен в експлоатация 1980 - 1989 г., Предлагаме ви, масивна , двуетажна,санирана къща с гараж, в централната част на с.Храбрино, с удобен ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Hrabrino Village, Plovdiv, Plovdiv. The property spans a total of 130 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 165000,
    "currency": "EUR",
    "locationBg": "с. Храбрино, област Пловдив",
    "locationEn": "Hrabrino Village, Plovdiv, Plovdiv",
    "cityKey": "с. Храбрино",
    "typeKey": "house",
    "sqMeters": 130,
    "rooms": 4,
    "bathrooms": 2,
    "yearBuilt": 1980,
    "image": "https://imotstatic3.focus.bg/imot/photosimotbg/1/031/1j177142383476031_2v.jpg",
    "gallery": [
      "https://imotstatic3.focus.bg/imot/photosimotbg/1/031/1j177142383476031_2v.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 38,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "6368 кв.м, Института по Тютюна, оферта 243.Предлагаме Ви парцел -земеделска земя в м.Пиринчийката.Лице на асфалт 56м.,срещу институт ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 6368 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 827840,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 6368,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 39,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "4499 кв.м, Лагера, оферта 239.Предлагаме Ви парцел- земеделска земя,в близост до бившият Лагер,м.Исака.За повече информ ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 4499 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 359920,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 4499,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 40,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "6999 кв.м, Стадиона, оферта 236.Предлагаме Ви парцел-нива- на 160м.от ул.Източна,на 160м.от нея и с лице 53м.на път.Прекр ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 6999 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 769890,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 6999,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 41,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "6001 кв.м, Стадиона, оферта 234.Предлагаме Ви парцел-нива в местността ИСАКА ,на 50м. от ул.Източна,с лице на път 56м.,в ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 6001 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 660110,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 6001,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 42,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Христо Смирненски",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "107 кв.м, 2-ри ет. от 6, Ще бъде въведен в експлоатация 2028 г., оферта 210.Предлагаме Ви за продажба тристаен слънчев апартамент в ново изграждащ се жилищен комплек ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Smirnenski Suburb, Plovdiv. The property spans a total of 107 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 144450,
    "currency": "EUR",
    "locationBg": "град Пловдив, Христо Смирненски",
    "locationEn": "Plovdiv, Smirnenski Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 107,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2028,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/865/1c177132189625865_f8.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/865/1c177132189625865_f8.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 43,
    "titleBg": "Продава ПАРЦЕЛ, с. Войводиново, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "12000 кв.м, Регулация, Вода, Оферта-140. ПРЕДЛАГАМЕ ВИ , ИМОТ С ПРОМЕНЕНО ПРЕДНАЗНАЧЕНИЕ ЗА ЖИЛ.ЗАСТРОЯВАНЕ , РАЗДЕЛЕН НА ОСЕМНАД ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Войводиново, Plovdiv, Plovdiv. The property spans a total of 12000 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 468000,
    "currency": "EUR",
    "locationBg": "с. Войводиново, област Пловдив",
    "locationEn": "с. Войводиново, Plovdiv, Plovdiv",
    "cityKey": "с. Войводиново",
    "typeKey": "land",
    "sqMeters": 12000,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/912/1r177365661244912_ds.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/912/1r177365661244912_ds.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 44,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1760 кв.м, оферта 242.Предлагаме Ви парцел в местността КОМСАЛА,НТП-лозе.Размери-69м,25м.Заповече информация и ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 1760 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 79200,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 1760,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 45,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "500 кв.м, стадиона, Регулация, Ток, Вода, Предлагаме ви парцел с променен статут за жилищно строителство до стадиона на с.Първенец .Всички ком ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 500 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 62000,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 500,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 46,
    "titleBg": "Продава ПАРЦЕЛ, с. Белащица, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "873 кв.м, вилна зона, Регулация, Ток, Вода, Оферта 224.Предлагаме Ви парцели във вилната зона на Белащица в приключваща процедура по смяня на ст ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Belashtitsa Village, Plovdiv, Plovdiv. The property spans a total of 873 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 104760,
    "currency": "EUR",
    "locationBg": "с. Белащица, област Пловдив",
    "locationEn": "Belashtitsa Village, Plovdiv, Plovdiv",
    "cityKey": "с. Белащица",
    "typeKey": "land",
    "sqMeters": 873,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/928/1r165337411571928_q5.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/928/1r165337411571928_q5.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 47,
    "titleBg": "Продава ЗАВЕДЕНИЕ, гр. Съединение, област Пловдив",
    "titleEn": "For Sale: ЗАВЕДЕНИЕ",
    "descriptionBg": "500 кв.м, Оферта 214.Предлагаме Ви търговски обект-голям ресторант със закрита търговска площ и открта градина ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in гр. Съединение, Plovdiv, Plovdiv. The property spans a total of 500 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 650000,
    "currency": "EUR",
    "locationBg": "гр. Съединение, област Пловдив",
    "locationEn": "гр. Съединение, Plovdiv, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 500,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/856/1m168327262866856_23.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/856/1m168327262866856_23.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 48,
    "titleBg": "Продава КЪЩА, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Family Home",
    "descriptionBg": "147 кв.м, двор 500 кв.м, Въведен в експлоатация 2020 г., Предлагаме Ви , изключително удобна и функционална,масивна, монолитна къща,в централната част на сел ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 147 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 329900,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "house",
    "sqMeters": 147,
    "rooms": 4,
    "bathrooms": 2,
    "yearBuilt": 2020,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/560/1j166212363765560_c3.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/560/1j166212363765560_c3.jpg"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 49,
    "titleBg": "Продава КЪЩА, с. Марково, област Пловдив",
    "titleEn": "For Sale: Family Home",
    "descriptionBg": "173 кв.м, двор 426 кв.м, 3 ет., Въведен в експлоатация, оферта 220.Предлагаме Ви самостоятелна монолитна къща,в центъра на МАРКОВО,с бетонни плочи между ета ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 173 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 380000,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "house",
    "sqMeters": 173,
    "rooms": 4,
    "bathrooms": 2,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/929/1j175129899584929_nj.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/929/1j175129899584929_nj.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 50,
    "titleBg": "Продава КЪЩА, с. Гълъбово, област Пловдив",
    "titleEn": "For Sale: Family Home",
    "descriptionBg": "220 кв.м, двор 570 кв.м, 1 ет. от 1, Ще бъде въведен в експлоатация 2026 г., оферта 211.Предлагаме Ви за продажба едноетажна къща,в самостоятелен парцел, с целогодишен достъп- м ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Гълъбово, Plovdiv, Plovdiv. The property spans a total of 220 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 330000,
    "currency": "EUR",
    "locationBg": "с. Гълъбово, област Пловдив",
    "locationEn": "с. Гълъбово, Plovdiv, Plovdiv",
    "cityKey": "с. Гълъбово",
    "typeKey": "house",
    "sqMeters": 220,
    "rooms": 4,
    "bathrooms": 2,
    "yearBuilt": 2026,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/448/1j177375059142448_5y.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/448/1j177375059142448_5y.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 51,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Гагарин",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "120 кв.м, 2-ри ет. от 10, Въведен в експлоатация, Оферта 102.Предлагаме Ви прекрасен тристаен апартамент в нова жилищна сграда с АКТ 16.Жилището е на ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Гагарин, Plovdiv. The property spans a total of 120 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 159990,
    "currency": "EUR",
    "locationBg": "град Пловдив, Гагарин",
    "locationEn": "Plovdiv, Гагарин, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 120,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2023,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/645/1c169581197452645_4A.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/645/1c169581197452645_4A.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 52,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Остромила",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "85 кв.м, 6-ти ет. от 6, оферта 237.Предлагаме Ви прекрасен панорамен апартамент с невероятна гледка и тераса.Намира се в нов ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Остромила, Plovdiv. The property spans a total of 85 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 118000,
    "currency": "EUR",
    "locationBg": "град Пловдив, Остромила",
    "locationEn": "Plovdiv, Остромила, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 85,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/705/1c174349266611705_1t.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/705/1c174349266611705_1t.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 53,
    "titleBg": "Продава 2-СТАЕН, град Пловдив, Христо Смирненски",
    "titleEn": "For Sale: 2-Room Apartment",
    "descriptionBg": "71 кв.м, 3-ти ет. от 6, Ще бъде въведен в експлоатация 2028 г., оферта 202.Предлагаме Ви за продажба двустаен слънчев апартамент в ново изграждащ се жилищен компле ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Smirnenski Suburb, Plovdiv. The property spans a total of 71 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 95850,
    "currency": "EUR",
    "locationBg": "град Пловдив, Христо Смирненски",
    "locationEn": "Plovdiv, Smirnenski Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 71,
    "rooms": 2,
    "bathrooms": 1,
    "yearBuilt": 2028,
    "image": "https://imotstatic3.focus.bg/imot/photosimotbg/1/116/1b177124323922116_m.jpg",
    "gallery": [
      "https://imotstatic3.focus.bg/imot/photosimotbg/1/116/1b177124323922116_m.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 54,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "602 кв.м, Регулация, Ток, Предлагаме ви 4бр.парцели за жилищно строителство на внора линия от асфалтовия път свързващ гр.Пловд ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 602 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 67500,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 602,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic3.focus.bg/imot/photosimotbg/1/759/1r178092161905759_ny.jpg",
    "gallery": [
      "https://imotstatic3.focus.bg/imot/photosimotbg/1/759/1r178092161905759_ny.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 55,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "585 кв.м, м.Комсала, Регулация, Предлагаме ви 2 бр.парцели за жилищно строителство на асфалтовия път за Борсата с лице на вътрешен ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 585 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 46215,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 585,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic3.focus.bg/imot/photosimotbg/1/743/1r175758791467743_h6.jpg",
    "gallery": [
      "https://imotstatic3.focus.bg/imot/photosimotbg/1/743/1r175758791467743_h6.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 56,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Кършияка",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "104 кв.м, бул.България, 2-ри ет. от 4, Въведен в експлоатация 2025 г., оферта 225.Предлагаме Ви за продажба тристаен непреходен апартамент в нова жилищна сграда с акт 16,о ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Karshiyaka Suburb, Plovdiv. The property spans a total of 104 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 163783,
    "currency": "EUR",
    "locationBg": "град Пловдив, Кършияка",
    "locationEn": "Plovdiv, Karshiyaka Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 104,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2025,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/759/1c177322894765759_ln.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/759/1c177322894765759_ln.jpg"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 57,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Кършияка",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "92 кв.м, бул.България, 2-ри ет. от 4, Въведен в експлоатация 2025 г., оферта 227.Предлагаме Ви за продажба тристаен непреходен апартамент в нова жилищна сграда с акт 16,о ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Karshiyaka Suburb, Plovdiv. The property spans a total of 92 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 145313,
    "currency": "EUR",
    "locationBg": "град Пловдив, Кършияка",
    "locationEn": "Plovdiv, Karshiyaka Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 92,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2025,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/003/1c177323053248003_P9.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/003/1c177323053248003_P9.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 58,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Гагарин",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "87 кв.м, 19-ти ет. от 19, ТЕЦ, Въведен в експлоатация, Оферта 216.Предлагаме Ви за продажба тристаен апартамент в квартал Гагарин.Апартамента представлява ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Гагарин, Plovdiv. The property spans a total of 87 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 165500,
    "currency": "EUR",
    "locationBg": "град Пловдив, Гагарин",
    "locationEn": "Plovdiv, Гагарин, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 87,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/887/1c176829487729887_xA.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/887/1c176829487729887_xA.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 59,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Тракия",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "98 кв.м, 5-ти ет. от 13, Ще бъде въведен в експлоатация 2027 г., оферта 238.Предлагаме Ви тристаен непреходен апартамент в новоизграждаща се жилищна сграда в сърцето ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Trakia Suburb, Plovdiv. The property spans a total of 98 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 143382,
    "currency": "EUR",
    "locationBg": "град Пловдив, Тракия",
    "locationEn": "Plovdiv, Trakia Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 98,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2027,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/810/1c177323191424810_YL.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/810/1c177323191424810_YL.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 60,
    "titleBg": "Продава 2-СТАЕН, град Пловдив, Тракия",
    "titleEn": "For Sale: 2-Room Apartment",
    "descriptionBg": "66 кв.м, Бирария Йегерхоф, 6-ти ет. от 13, Ще бъде въведен в експлоатация 2027 г., оферта 235.Предлагаме Ви двустаен непреходен апартамент в новоизграждаща се жилищна сграда в сърцето ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Trakia Suburb, Plovdiv. The property spans a total of 66 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 106159,
    "currency": "EUR",
    "locationBg": "град Пловдив, Тракия",
    "locationEn": "Plovdiv, Trakia Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 66,
    "rooms": 2,
    "bathrooms": 1,
    "yearBuilt": 2027,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/671/1b177323305571671_J8.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/671/1b177323305571671_J8.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 61,
    "titleBg": "Продава 2-СТАЕН, град Пловдив, Кършияка",
    "titleEn": "For Sale: 2-Room Apartment",
    "descriptionBg": "77 кв.м, 2-ри ет. от 4, Въведен в експлоатация 2025 г., оферта 213.Предлагаме Ви за продажба двустаен непреходен апартамент в нова жилищна сграда с акт 16,о ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Karshiyaka Suburb, Plovdiv. The property spans a total of 77 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 129427,
    "currency": "EUR",
    "locationBg": "град Пловдив, Кършияка",
    "locationEn": "Plovdiv, Karshiyaka Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 77,
    "rooms": 2,
    "bathrooms": 1,
    "yearBuilt": 2025,
    "image": "https://imotstatic3.focus.bg/imot/photosimotbg/1/830/1b177322835664830_jC.jpg",
    "gallery": [
      "https://imotstatic3.focus.bg/imot/photosimotbg/1/830/1b177322835664830_jC.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 62,
    "titleBg": "Продава КЪЩА, гр. Шабла, област Добрич",
    "titleEn": "For Sale: Family Home",
    "descriptionBg": "106 кв.м, двор 915 кв.м, 1 ет. от 1, Въведен в експлоатация 1960 - 1969 г., Предлагаме ви здрава, едноетажна, монолитна къща, намираща се в близост до центъра на гр.Шабла.Къщат ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in гр. Шабла, област Добрич, Plovdiv. The property spans a total of 106 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 63000,
    "currency": "EUR",
    "locationBg": "гр. Шабла, област Добрич",
    "locationEn": "гр. Шабла, област Добрич, Plovdiv",
    "cityKey": "гр. Шабла",
    "typeKey": "house",
    "sqMeters": 106,
    "rooms": 4,
    "bathrooms": 2,
    "yearBuilt": 1960,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/618/1j175284240143618_gV.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/618/1j175284240143618_gV.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 63,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Христо Смирненски",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "86 кв.м, 6-ти ет. от 6, Ще бъде въведен в експлоатация 2027 г., оферта 205.Предлагаме Ви за продажба тристаен маломерен апартамент в ново изграждаща се жилищна сгра ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Smirnenski Suburb, Plovdiv. The property spans a total of 86 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 135309,
    "currency": "EUR",
    "locationBg": "град Пловдив, Христо Смирненски",
    "locationEn": "Plovdiv, Smirnenski Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 86,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2027,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/640/1c177037998163640_P5.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/640/1c177037998163640_P5.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 64,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Христо Смирненски",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "113 кв.м, 2-ри ет. от 6, Ще бъде въведен в експлоатация 2027 г., оферта 204.Предлагаме Ви за продажба тристаен апартамент в ново изграждаща се жилищна сграда със сте ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Smirnenski Suburb, Plovdiv. The property spans a total of 113 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 168000,
    "currency": "EUR",
    "locationBg": "град Пловдив, Христо Смирненски",
    "locationEn": "Plovdiv, Smirnenski Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 113,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2027,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/596/1c177038091018596_8L.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/596/1c177038091018596_8L.jpg"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 65,
    "titleBg": "Продава 2-СТАЕН, град Пловдив, Христо Смирненски",
    "titleEn": "For Sale: 2-Room Apartment",
    "descriptionBg": "44 кв.м, 5-ти ет. от 6, Ще бъде въведен в експлоатация 2027 г., оферта 208.Предлагаме Ви за продажба двустаен апартамент в ново изграждаща се жилищна сграда със сте ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Smirnenski Suburb, Plovdiv. The property spans a total of 44 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 77800,
    "currency": "EUR",
    "locationBg": "град Пловдив, Христо Смирненски",
    "locationEn": "Plovdiv, Smirnenski Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 44,
    "rooms": 2,
    "bathrooms": 1,
    "yearBuilt": 2027,
    "image": "https://imotstatic3.focus.bg/imot/photosimotbg/1/487/1b177038194370487_Dx.jpg",
    "gallery": [
      "https://imotstatic3.focus.bg/imot/photosimotbg/1/487/1b177038194370487_Dx.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 66,
    "titleBg": "Продава 1-СТАЕН, град Пловдив, Кършияка",
    "titleEn": "For Sale: 1-СТАЕН",
    "descriptionBg": "35 кв.м, У-ще Райна Кнегиня, 2-ри ет. от 5, Въведен в експлоатация 2015 г., Оферта 103.Предлагаме ново, завършено и обзаведено жилище с изба, с площ около 3кв.м. на партерния е ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Karshiyaka Suburb, Plovdiv. The property spans a total of 35 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 84990,
    "currency": "EUR",
    "locationBg": "град Пловдив, Кършияка",
    "locationEn": "Plovdiv, Karshiyaka Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 35,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2015,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/1/008/1a178049289825008_mR.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/1/008/1a178049289825008_mR.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 67,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1434 кв.м, м.Пичковец, Регулация, Ток, Вода, Предлагаме Ви парцел със сменено предназначение за жилищно строителство-УПИ ,находящо се в м.ПИЧКОВЕ ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 1434 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 209000,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 1434,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/686/1r177789519152686_q1.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/686/1r177789519152686_q1.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 68,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "535 кв.м, Регулация, Ток, Вода, оферта 107.Предлагаме ви, 2бр.парцела за жилищно строителство с достъп от главния асфалтов път на с ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 535 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 65500,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 535,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 69,
    "titleBg": "Продава ХОТЕЛ, с. Нареченски бани, област Пловдив",
    "titleEn": "For Sale: ХОТЕЛ",
    "descriptionBg": "2400 кв.м, център, Въведен в експлоатация, ОФЕРТА 251.Предлагаме Ви имот,който е фунцкционирал като почивна станция, на брега на река Чая в се ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Нареченски бани, Plovdiv, Plovdiv. The property spans a total of 2400 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 349000,
    "currency": "EUR",
    "locationBg": "с. Нареченски бани, област Пловдив",
    "locationEn": "с. Нареченски бани, Plovdiv, Plovdiv",
    "cityKey": "с. Нареченски бани",
    "typeKey": "commercial",
    "sqMeters": 2400,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/577/1q171742639238577_tW.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/577/1q171742639238577_tW.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 70,
    "titleBg": "Продава ПРОМ. ПОМЕЩЕНИЕ, с. Йоаким Груево, област Пловдив",
    "titleEn": "For Sale: ПРОМ. ПОМЕЩЕНИЕ",
    "descriptionBg": "840 кв.м, 2000 г., Оферта 113.Предлагаме ви промишлено хале-450 кв.м., офисна сграда - 90 кв.м. и масивен навес-300 кв. ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Йоаким Груево, Plovdiv, Plovdiv. The property spans a total of 840 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 380000,
    "currency": "EUR",
    "locationBg": "с. Йоаким Груево, област Пловдив",
    "locationEn": "с. Йоаким Груево, Plovdiv, Plovdiv",
    "cityKey": "с. Йоаким Груево",
    "typeKey": "apartment",
    "sqMeters": 840,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/099/1p170176484006099_zF.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/099/1p170176484006099_zF.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 71,
    "titleBg": "Продава ЗАВЕДЕНИЕ, гр. Съединение, област Пловдив",
    "titleEn": "For Sale: ЗАВЕДЕНИЕ",
    "descriptionBg": "140 кв.м, ОФЕРТА 217.Предлгаме Ви две търговски помещения-застроени на калкан ,разположени в два съседни парце ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in гр. Съединение, Plovdiv, Plovdiv. The property spans a total of 140 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 149000,
    "currency": "EUR",
    "locationBg": "гр. Съединение, област Пловдив",
    "locationEn": "гр. Съединение, Plovdiv, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 140,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/873/1m170963215660873_z2.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/873/1m170963215660873_z2.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 72,
    "titleBg": "Продава МАГАЗИН, град Пловдив, Център",
    "titleEn": "For Sale: Commercial Storefront",
    "descriptionBg": "160 кв.м, Централна гара, Оферта 212.Предлагаме Ви магазин на централно място в близост до кино Гео Милев.,с лице на булевард ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, City Center, Plovdiv. The property spans a total of 160 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 249000,
    "currency": "EUR",
    "locationBg": "град Пловдив, Център",
    "locationEn": "Plovdiv, City Center, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "commercial",
    "sqMeters": 160,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/1/546/1l155368396059546_DH.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/1/546/1l155368396059546_DH.jpg"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 73,
    "titleBg": "Дава под наем 3-СТАЕН, град Пловдив, Център",
    "titleEn": "For Rent: 3-Room Apartment",
    "descriptionBg": "90 кв.м, Медицински Университет, 3-ти ет. от 5, Предлагаме Ви Тристайно жилище под наем в тухлена сграда на десет минути пешеходно разстояние от цен ...,",
    "descriptionEn": "We are pleased to introduce this property listed for rent in Plovdiv, City Center, Plovdiv. The property spans a total of 90 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 800,
    "currency": "EUR",
    "locationBg": "град Пловдив, Център",
    "locationEn": "Plovdiv, City Center, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 90,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2023,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/2/782/2d178004228708782_yu.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/2/782/2d178004228708782_yu.jpg",
      "https://imotstatic1.focus.bg/imot/photosimotbg/2/782/2d178004228708782_t4.jpg",
      "https://imotstatic1.focus.bg/imot/photosimotbg/2/782/2d178004228708782_DG.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 74,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "770 кв.м, Регулация, Ток, Вода, Предлагаме ви, уникален имот, за жилищно застрояване , находящ се на асфалтова улица в централната ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 770 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 99900,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 770,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/073/1r169297466720073_Ag.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/073/1r169297466720073_Ag.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 75,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "4998 кв.м, Предлагаме Ви парцел в местност ТАШЛЪКА,нива,4 категория.Размери -30м.лице на второстепенен път,дълб ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 4998 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 84966,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 4998,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 76,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "2800 кв.м, оферта 233.Предлагаме Ви парцел в непосредствена близост до къщи,с панорамна гледка към Пловдив.В бл ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 2800 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 140000,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 2800,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic3.focus.bg/imot/photosimotbg/1/257/1r177246005789257_CL.jpg",
    "gallery": [
      "https://imotstatic3.focus.bg/imot/photosimotbg/1/257/1r177246005789257_CL.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 77,
    "titleBg": "Продава ПАРЦЕЛ, с. Войводиново, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "702 кв.м, ВЛАДИМИРОВ ЧИФЛИК, Регулация, Ток, Вода, Оферта 304. Предлагаме ви УПИ в началото на с.Войводиново,в съседство с построени къщи.Имотът е с вс ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Войводиново, Plovdiv, Plovdiv. The property spans a total of 702 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 57000,
    "currency": "EUR",
    "locationBg": "с. Войводиново, област Пловдив",
    "locationEn": "с. Войводиново, Plovdiv, Plovdiv",
    "cityKey": "с. Войводиново",
    "typeKey": "land",
    "sqMeters": 702,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/223/1r175223186458223_mZ.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/223/1r175223186458223_mZ.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 78,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "2100 кв.м, оферта 219.Предлагаме Ви парцел в непосредствена близост до къщи,с панорамна гледка към Пловдив.В бл ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 2100 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 126000,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 2100,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/021/1r177245159603021_Si.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/021/1r177245159603021_Si.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 79,
    "titleBg": "Продава ПАРЦЕЛ, град Пловдив, Индустриална зона - Изток",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "6001 кв.м, Главния път за гр.Харманл, Регулация, Оферта 138.Предлагаме ви уникален инвестиционен имот - УПИ, отреден за база за селскостопанска или г ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Индустриална зона - Изток, Plovdiv. The property spans a total of 6001 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 0,
    "currency": "EUR",
    "locationBg": "град Пловдив, Индустриална зона - Изток",
    "locationEn": "Plovdiv, Индустриална зона - Изток, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 6001,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic2.focus.bg/imot/photosimotbg/1/689/1r171592907385689_4b.jpg",
    "gallery": [
      "https://imotstatic2.focus.bg/imot/photosimotbg/1/689/1r171592907385689_4b.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 80,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "4549 кв.м, Регулация, оферта 203.Предлагаме Ви за продажба парцел със стартирала процедура по смяна на статута за промишле ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 4549 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 295685,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 4549,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 81,
    "titleBg": "Дава под наем ПРОМ. ПОМЕЩЕНИЕ, град Пловдив, Индустриална зона - Юг",
    "titleEn": "For Rent: ПРОМ. ПОМЕЩЕНИЕ",
    "descriptionBg": "1200 кв.м, околовръстното шосе, 1-ви ет. от 1, Предлагаме ви хале на много комуникативно място в южната част на околовр.шосе, в близост до разклона ...,",
    "descriptionEn": "We are pleased to introduce this property listed for rent in Plovdiv, Industrial Zone - South, Plovdiv. The property spans a total of 1200 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 3300,
    "currency": "EUR",
    "locationBg": "град Пловдив, Индустриална зона - Юг",
    "locationEn": "Plovdiv, Industrial Zone - South, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 1200,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/2/416/2q175517206148416_Dc.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/2/416/2q175517206148416_Dc.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 82,
    "titleBg": "Дава под наем СКЛАД, с. Марково, област Пловдив",
    "titleEn": "For Rent: Industrial Warehouse",
    "descriptionBg": "100 кв.м, Партер от 2, ПРЕДЛАГАМЕ Ви помещение в центъра на с.МАРКОВО ,със статут на цех за производство на сладкарски и те ...,",
    "descriptionEn": "We are pleased to introduce this property listed for rent in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 100 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 440,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "industrial",
    "sqMeters": 100,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 83,
    "titleBg": "Дава под наем 3-СТАЕН, град Пловдив, Мараша",
    "titleEn": "For Rent: 3-Room Apartment",
    "descriptionBg": "100 кв.м, Ул.Младежка, 5-ти ет. от 7, Предлагаме Ви, ункален, тристаен апартамент в НОВА сграда ,с луксозно изпълнение, на комуникативна ...,",
    "descriptionEn": "We are pleased to introduce this property listed for rent in Plovdiv, Мараша, Plovdiv. The property spans a total of 100 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 1299,
    "currency": "EUR",
    "locationBg": "град Пловдив, Мараша",
    "locationEn": "Plovdiv, Мараша, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 100,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2023,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/2/106/2d176952130892106_6e.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/2/106/2d176952130892106_6e.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 84,
    "titleBg": "Дава под наем 2-СТАЕН, град Пловдив, Младежки Хълм",
    "titleEn": "For Rent: 2-Room Apartment",
    "descriptionBg": "60 кв.м, ВМИ, 3-ти ет. от 6, Предлагаме Ви двустаен напълно обзаведен апартамент в нова монолитна сграда с луксозни общи части ,к ...,",
    "descriptionEn": "We are pleased to introduce this property listed for rent in Plovdiv, Младежки Хълм, Plovdiv. The property spans a total of 60 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 550,
    "currency": "EUR",
    "locationBg": "град Пловдив, Младежки Хълм",
    "locationEn": "Plovdiv, Младежки Хълм, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 60,
    "rooms": 2,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/2/824/2c177461708453824_S8.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/2/824/2c177461708453824_S8.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 85,
    "titleBg": "Продава ПАРЦЕЛ, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1500 кв.м, Регулация, Ток, Оферта-136 ПРЕДЛАГАМЕ ВИ УРЕГУЛИРАН ИМОТ, С ВЪТРЕШЕН ПЪТ В С.ПЪРВЕНЕЦ, В РАЙОН ЗАСТРОЕН С НОВИ КЪЩИ ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 1500 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 82500,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "land",
    "sqMeters": 1500,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://imotstatic1.focus.bg/imot/photosimotbg/1/416/1r171465374011416_EK.jpg",
    "gallery": [
      "https://imotstatic1.focus.bg/imot/photosimotbg/1/416/1r171465374011416_EK.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 86,
    "titleBg": "Продава КЪЩА, с. Първенец, област Пловдив",
    "titleEn": "For Sale: Family Home",
    "descriptionBg": "200 кв.м, двор 400 кв.м, 2 ет. от 2, Въведен в експлоатация 2021 г., Предлагаме ви , уникална, нова, изключително функционална, модерно обзаведена къща , с панорамна гле ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Parvenets Village, Plovdiv, Plovdiv. The property spans a total of 200 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 398000,
    "currency": "EUR",
    "locationBg": "с. Първенец, област Пловдив",
    "locationEn": "Parvenets Village, Plovdiv, Plovdiv",
    "cityKey": "с. Първенец",
    "typeKey": "house",
    "sqMeters": 200,
    "rooms": 4,
    "bathrooms": 2,
    "yearBuilt": 2021,
    "image": "https://imotstatic4.focus.bg/imot/photosimotbg/1/228/1j174170006434228_1.jpg",
    "gallery": [
      "https://imotstatic4.focus.bg/imot/photosimotbg/1/228/1j174170006434228_1.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 87,
    "titleBg": "Продава ПАРЦЕЛ, с. Скутаре, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "8700 кв.м, Предлагаме Ви парцел с лице 56м. на главнивт път за с.Скутаре ,на изхода от Пловдив,до завод DUSITEX ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Скутаре, Plovdiv, Plovdiv. The property spans a total of 8700 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 435000,
    "currency": "EUR",
    "locationBg": "с. Скутаре, област Пловдив",
    "locationEn": "с. Скутаре, Plovdiv, Plovdiv",
    "cityKey": "с. Скутаре",
    "typeKey": "land",
    "sqMeters": 8700,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 88,
    "titleBg": "Продава ПАРЦЕЛ, с. Брестник, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "1920 кв.м, Регулация, Оферта 228.ПРЕДЛАГАМЕ Ви два съседни УРЕГУЛИРАНИ поземлени имота- с чиста площ от 1690кв.м.и прилежа ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Брестник, Plovdiv, Plovdiv. The property spans a total of 1920 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 105600,
    "currency": "EUR",
    "locationBg": "с. Брестник, област Пловдив",
    "locationEn": "с. Брестник, Plovdiv, Plovdiv",
    "cityKey": "с. Брестник",
    "typeKey": "land",
    "sqMeters": 1920,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": true,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 89,
    "titleBg": "Продава ПАРЦЕЛ, магистрала Тракия, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "7220 кв.м, Цалапица, Предлагаме Ви пацел-земеделска земя(нива) с лице на Магистрала Тракия-48м.,на ок.два км.,от отбивкат ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Trakia Suburb, Plovdiv, Plovdiv. The property spans a total of 7220 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 115520,
    "currency": "EUR",
    "locationBg": "магистрала Тракия, област Пловдив",
    "locationEn": "Trakia Suburb, Plovdiv, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "land",
    "sqMeters": 7220,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 90,
    "titleBg": "Продава 3-СТАЕН, град Пловдив, Христо Смирненски",
    "titleEn": "For Sale: 3-Room Apartment",
    "descriptionBg": "118 кв.м, новия Лидл, 6-ти ет. от 6, Ще бъде въведен в експлоатация 2025 г., оферта 222.Предлагаме Ви прекрасен слънчев апартамент с югоизточно изложение.Намира се в нова жилищн ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Plovdiv, Smirnenski Suburb, Plovdiv. The property spans a total of 118 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 148000,
    "currency": "EUR",
    "locationBg": "град Пловдив, Христо Смирненски",
    "locationEn": "Plovdiv, Smirnenski Suburb, Plovdiv",
    "cityKey": "Пловдив",
    "typeKey": "apartment",
    "sqMeters": 118,
    "rooms": 3,
    "bathrooms": 2,
    "yearBuilt": 2025,
    "image": "https://cdn3.focus.bg/imot/photosimotbg/1/574/1c174219932537574_Xm.jpg",
    "gallery": [
      "https://cdn3.focus.bg/imot/photosimotbg/1/574/1c174219932537574_Xm.jpg"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 91,
    "titleBg": "Продава ПАРЦЕЛ, с. Цалапица, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "3600 кв.м, лице на пазаджишко шосе, Оферта 119.Предлагаме ви парцел с лице на Пазаджишко шосе 23,60м.до разклона за Цалапица.Има опция и ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in с. Цалапица, Plovdiv, Plovdiv. The property spans a total of 3600 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 72000,
    "currency": "EUR",
    "locationBg": "с. Цалапица, област Пловдив",
    "locationEn": "с. Цалапица, Plovdiv, Plovdiv",
    "cityKey": "с. Цалапица",
    "typeKey": "land",
    "sqMeters": 3600,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  },
  {
    "id": 92,
    "titleBg": "Продава ПАРЦЕЛ, с. Марково, област Пловдив",
    "titleEn": "For Sale: Development Land Plot",
    "descriptionBg": "6670 кв.м, Оферта 241.Предлагаме Ви земеделска земя-черешова градина ,в близост до новият път за с.Марково,в бл ...,",
    "descriptionEn": "We are pleased to introduce this property listed for sale in Markovo Village, Plovdiv, Plovdiv. The property spans a total of 6670 sq.m. of functional area. It represents an outstanding opportunity either for personal residential comfort or as a high-yield investment asset. For more information and to schedule an exclusive viewing, please contact our Plovdiv office and mention the listing.",
    "price": 66700,
    "currency": "EUR",
    "locationBg": "с. Марково, област Пловдив",
    "locationEn": "Markovo Village, Plovdiv, Plovdiv",
    "cityKey": "с. Марково",
    "typeKey": "land",
    "sqMeters": 6670,
    "rooms": 1,
    "bathrooms": 1,
    "yearBuilt": 2023,
    "image": "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80",
    "gallery": [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=1200&q=80"
    ],
    "featured": false,
    "featuresBg": [
      "Нова обява",
      "Проверена от юрист",
      "Отлична локация",
      "Комфорт и сигурност"
    ],
    "featuresEn": [
      "New Listing",
      "Legally Cleared",
      "Top Location",
      "Comfort & Safety"
    ]
  }
];

export const blogPosts: BlogPost[] = [
  {
    "id": 1,
    "titleBg": "Как да купим имот безопасно в България: Пълно ръководство за 2026",
    "titleEn": "How to Safely Buy a Home in Bulgaria: A Complete 2026 Guide",
    "excerptBg": "Всички правни и финансови детайли, стъпки за проверка на собствеността, такси при нотариус и как да избегнем скрити рискове.",
    "excerptEn": "Expert insights into legal and financial checks, property title deeds verification, notary taxes, and avoiding hidden buyer traps.",
    "contentBg": "Покупката на жилище е сред най-важните финансови решения в живота. Българският пазар на недвижими имоти е изключително динамичен през 2026 година, което крие както големи възможности, така и скрити капани за неинформирания купувач. \n\nВ тази статия нашият екип от Bell Estate Group обобщава петте задолжителни стъпки, през които трябва да преминете, за да гарантирате 100% защита на вашата инвестиция:\n\n1. **Цялостна проверка на собствеността и вещните права (Търговски и Имотен Регистър)**\nНикога не разчитайте единствено на думите на продавача или на предоставения стар нотариален акт. Препоръчително е да извадите пълна историческа справка за имота от Агенцията по вписванията за поне 10 години назад, за да сте сигурни, че няма вписани ипотеки, възбрани, договори за наем или висящи съдебни спорове.\n\n2. **Задължителна проверка за липса на тежести**\nОфициалното Удостоверение за вещни тежести (УВТ) се издава в деня на самата сделка или непосредствено преди нея. Това е вашият официален щит срещу неочаквани ипотеки.\n\n3. **Внимателен анализ на предварителния договор**\nПредварителният договор урежда сроковете, неустойките при неспазване и етапите на плащане. В Bell Estate Group нашите адвокати изготвят индивидуални договори за всяка сделка, отхвърляйки предварително породени стандартни формуляри тип шаблони, които биха ощетили купувача.\n\n4. **Преводи на средства по специална банкова доверителна сметка**\nС цел превенция на измами, плащанията за големи трансакции се реализират изключително по банков път, често посредством Ескроу сметка (Доверителна попечителска банкова сметка), при която банката освобождава превода към продавача само при наличното реално подписване и вписване на новия Нотариален акт.\n\n5. **Оценка и сътрудничество с доверен посредник**\nПосредникът не е просто човек, който отваря врати – той е архитектът на правната безопасност на сделката. Bell Estate Group носи пълна юридическа отговорност за легалността на прехвърляните имоти в нашия каталог. Попитайте ни безплатно за всякакви въпроси днес!",
    "contentEn": "Buying a home is one of the most significant financial steps in any lifetime. The Bulgarian real estate market is highly active in 2026, offering outstanding investment opportunities alongside critical legal risks for uninformed clients.\n\nIn this editorial, our expert legal team at Bell Estate Group details five paramount steps to completely safeguard your premium real estate investment:\n\n1. **Independent History Check on the Property Registry**\nNever rely solely on friendly verbal guarantees or even the physical copy of an old title deed. Our legal team pulls an official history extract spanning at least 10 preceding years from the central Registry Agency. This outlines whether previous successions, legacy inheritance claims, or pending court cases exist.\n\n2. **The Absolute Certificate of Obstacles (No Encumbrances)**\nThe official \"Certificate of Encumbrances\" (УВТ in Bulgarian) stands as your bulletproof legal protection. It certifies that the target house is perfectly clear of active commercial bank mortgages, private debt seizures, or litigation claims on the exact morning of contract finalization.\n\n3. **Meticulous Preparation of the Preliminary Purchase Agreement**\nThis document locks in the purchase price, timelines, and execution penalties. At Bell Estate Group, we write tailored custom contracts specifically matching your target layout and conditions, refusing to work with high-risk templated contracts that leave buyers exposed if a contractor delays work.\n\n4. **Ensuring Transaction Integrity with Bank Escrow Accounts**\nFinancial settlements exceeding BGN 10,000 must occur via certified bank wires. For ultimate high-end safety, utilizing a designated bank Escrow Account ensures that your capital is only released after the official transfer of the new title deed is stamp-approved by the Presiding Notary and registered.\n\n5. **Partnering with a Transparent, Licensed Agency**\nA proper real estate consultant is not a casual tour guide – they are the strict guardians of your capital. Bell Estate Group acts as your dedicated advocate, guaranteeing legal clarity on every villa listed under our portfolio. Reach out to our firm to set up your free consultation today!",
    "date": "2026-06-15",
    "categoryBg": "Правни Съвети",
    "categoryEn": "Legal Advocacy",
    "readTimeBg": "5 мин. четене",
    "readTimeEn": "5 min read",
    "image": "https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80"
  },
  {
    "id": 2,
    "titleBg": "Тенденции на пазара на луксозни имоти през 2026 година в България",
    "titleEn": "2026 Premium Real Estate Trends in Major Bulgarian Cities",
    "excerptBg": "Търсенето на пасивни къщи, засенчването на стандартното ново строителство от затворени интелигентни квартали и влиянието на еврозоната.",
    "excerptEn": "The rising green demand for passive homes, high-end private gated communities over high-rises, and the economic consolidation of Euro integration.",
    "contentBg": "През 2026 пазарът в София, Пловдив и Варна навлиза в нов етап на зрялост. Вече не се търси просто квадратен метър застроена площ – клиентите на луксозния сегмент купуват начин на живот, здравословна среда и финансова устойчивост.\n\nПървият водещ тренд е **абсолютната доминация на устойчивите сгради**. Къщи с енергиен клас А+ и пасивни фасади, оборудвани със собствени ВЕИ (възобновяеми енергийни източници), се разпродават изключително бързо. В контекста на нестабилни глобални енергийни източници, автономността се превръща в най-новия лукс.\n\nВторият акцент е **пренасочването към затворени крайградски комплекси**. Квартали като Бояна, Драгалевци, Симеоново и Панчарево в София отчитат огромен ръст в инвестиционния интерес. Хората търсят спокойствие, свеж планински въздух, професионална охрана 24/7 и озеленени алеи, далеч от претоварения градски шум.\n\nНа трето място, **интеграцията на България в еврозоната** допринесе за допълнително заздравяване на доверието от страна на чуждестранни инвеститори и улесни трансграничните ипотечни придобивания. Пазарът е стабилен, без спекулативни пикове, а сигурността на активите е гарантирана.",
    "contentEn": "In 2026, the real estate landscape across Sofia, Plovdiv, and Varna has unlocked an era of absolute sophistication. Buyers are no longer purchasing raw brick-and-mortar space; elite clients are acquiring a secure lifestyle, physical wellness, and ecological sustainability.\n\nThe premier trend is the **unrivaled priority of zero-emission passive architecture**. Luxury villas certified under Class A+ green energy ratings, featuring rooftop micro-solar arrays and advanced air heat pumps, are receiving premium bids. True autonomy is recognized as the ultimate contemporary amenity.\n\nSecondly, the **migration towards gated suburban clusters is accelerating**. Suburbs like Boyana, Dragalevtsi, and Pancharevo in Sofia, alongside Evksinograd in Varna, have witnessed extraordinary high-end transaction volume. Modern families actively prioritize fresh mountain clean air, monitored private security patrols, and spacious walking parkways.\n\nFinally, **Bulgaria's deeper integration within the European financial ecosystem and the Eurozone** has anchored foreign investor security. European institutional investors and expat professionals are acquiring premium local properties as stable long-term assets, bringing a high degree of healthy value appreciation to the local market.",
    "date": "2026-06-02",
    "categoryBg": "Пазарен Анализ",
    "categoryEn": "Market Reports",
    "readTimeBg": "4 мин. четене",
    "readTimeEn": "4 min read",
    "image": "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=800&q=80"
  }
];

export const translations = {
  "bg": {
    "brandName": "BellEstateGroup",
    "brandTagline": "агенция - недвижими имоти",
    "navHome": "Начало",
    "navListings": "Портфолио",
    "navServices": "Услуги",
    "navBlog": "Пазарен Офис",
    "navConsultation": "Безплатна Консултация",
    "navContact": "Адрес и Контакти",
    "heroTitle": "Вашата сигурна стъпка към мечтания нов дом",
    "heroSubtitle": "С над 18 години професионален опит и над 1000 успешно реализирани сделки в град Пловдив и цялата страна, ние от BellEstateGroup осъществяваме Вашите планове с пълна юридическа подкрепа, почтеност и професионализъм.",
    "searchPlaceholder": "Търсете по локация, квартал...",
    "filterType": "Тип имот",
    "filterCity": "Локация/Град",
    "allTypes": "Всички видове",
    "allCities": "Всички градове",
    "priceRange": "Бюджет (до)",
    "btnSearch": "Намерете Имоти",
    "house": "Фамилна Къща",
    "villa": "Луксозна Вила",
    "apartment": "Аристократичен Апартамент",
    "penthouse": "Пентхаус Мезонет",
    "sofia": "София",
    "varna": "Вarna (Варна)",
    "plovdiv": "Пловдив",
    "burgas": "Бургас",
    "bansko": "Банско",
    "sqmLabel": "кв.м.",
    "roomsLabel": "стаи",
    "bathroomsLabel": "бани",
    "yearLabel": "година",
    "priceLabel": "Цена:",
    "viewDetails": "Вижте Детайли",
    "closeBtn": "Затвори",
    "featuresTitle": "Удобства и инсталации",
    "descriptionTitle": "Описание на имота",
    "specificationsTitle": "Параметри на сградата",
    "inquiryTitle": "Изпратете запитване за този имот",
    "trustTitle": "Фундаментът на BellEstateGroup е Вашето доверие",
    "trustSubtitle": "Ние не просто продаваме сгради. Ние гарантираме Вашето спокойствие с безкомпромисна почтеност.",
    "value1Title": "Правна Гаранция от 100%",
    "value1Desc": "Всеки имот в нашето портфолио преминава през задълбочена юридическа проверка за тежести, история на собствеността и вещни права от нашите вътрешни юристи.",
    "value2Title": "Лична Прозрачност",
    "value2Desc": "Без скрити условия, такси или изкуствено надути цени. Всички преговори се водят открито и почтено с директния собственик.",
    "value3Title": "Бизнес Прецизност",
    "value3Desc": "Работим с квалифицирани брокери, геодезисти и архитекти, предоставяйки комплексни инженерни, правни и посреднически оценки за всеки обект.",
    "value4Title": "Дискретност и Елитност",
    "value4Desc": "Запазваме абсолютна конфиденциалност и конфигурираме сделки според индивидуалните инвестиционни планове на нашите клиенти.",
    "stat1No": "над 18 год.",
    "stat1Lb": "Професионален Опит",
    "stat2No": "1000+",
    "stat2Lb": "Успешно Реализирани Сделки",
    "stat3No": "100%",
    "stat3Lb": "Чисти Сделки без съдебни спорове",
    "stat4No": "4.9/5",
    "stat4Lb": "Оценка от Премиум Клиенти",
    "sectionFeatured": "Репрезентативни Имоти",
    "sectionFeaturedSub": "Селектирани луксозни имоти, готови за нанасяне или инвестиция, отговарящи на най-високите европейски стандарти.",
    "sectionBlog": "Пазарен Офис & Анализи",
    "sectionBlogSub": "Професионални статии, правни съвети и пазарни отчети за безопасно и доходоносно управление на недвижими имоти.",
    "sectionConsultation": "Резервирайте Безплатна Консултация",
    "sectionConsultationSub": "Изберете удобна за Вас дата и час. Нашият мениджър по сделките ще се свърже с Вас, за да анализира Вашите инвестиционни нужди.",
    "sectionContact": "Свържете се с Нас",
    "sectionContactSub": "Посетете нашия офис в град Пловдив или изпратете бързо запитване чрез нашата защитена уеб форма.",
    "bookingFormName": "Вашето Име",
    "bookingFormEmail": "Имейл Адрес",
    "bookingFormPhone": "Телефонен Номер",
    "bookingFormNotes": "Допълнителна информация (бюджет, желан имот...)",
    "bookingFormType": "Тема на консултацията",
    "bookingTypeBuy": "Покупка на Нов Дом",
    "bookingTypeSell": "Продажба на Имот",
    "bookingTypeLegal": "Правна консултация / Проверка на тежести",
    "bookingTypeInvestment": "Инвестиции в Зелена Енергия и Имоти",
    "bookingTypeOther": "Друго",
    "bookingCalendarTitle": "Изберете Дата и Наличен Час",
    "bookingBtn": "Потвърдете Вашата Резервация",
    "bookingSuccess": "Благодарим Ви! Вашата консултация е запазена успешно. Наш консултант ще Ви позвъни за кратко потвърждение.",
    "contactName": "Вашите три имена",
    "contactEmail": "Вашият Личен Имейл",
    "contactPhone": "Контактен Телефон",
    "contactMessage": "Съобщение (Опишете вашето търсене)",
    "contactSendBtn": "Изпратете Съобщение",
    "contactSuccess": "Вашето запитване е изпратено успешно! Благодарим ви, наш сътрудник ще се свърже с Вас в рамките на 2 работни часа.",
    "contactOfficeTitle": "Нашият Централен Офис",
    "contactAddress": "Даме Груев 18 гр.Пловдив",
    "contactWorktime": "Работно Време: Пон - Пет: 08:30 - 18:00ч | Съб: 10:00 - 17:00ч | Нед: по спешност",
    "contactPhoneVal": "032260510, 0898573681, 0889461275",
    "contactEmailVal": "estate_07@abv.bg",
    "followUs": "Последвайте ни в социалните мрежи",
    "portfolioTitle": "Премиум Портфолио Имоти",
    "portfolioSubtitle": "Открийте Вашия нов дом или сигурна инвестиция сред специално проверени и подбрани обекти.",
    "sortBy": "Сортиране",
    "sortPriceAsc": "Цена: Низходяща към Възходяща",
    "sortPriceDesc": "Цена: Възходяща към Низходяща",
    "sortSqmAsc": "Квадратура: Най-малки първи",
    "sortSqmDesc": "Квадратура: Най-големи първи",
    "noResults": "Няма намерени имоти по зададените филтри. Моля, нулирайте филтрите или опитайте ново търсене.",
    "resetFilters": "Изчисти Филтрите",
    "readPost": "Прочети цялата статия",
    "backToBlog": "Обратно към всички статии",
    "footerRights": "Всички права запазени. Bell Estate Group.",
    "footerLegalInfo": "Дружеството е лицензиран посредник на недвижими имоти и притежава пълна сертификация по БДС EN 15733.",
    "footerQuickLinks": "Бърз достъп"
  },
  "en": {
    "brandName": "BellEstateGroup",
    "brandTagline": "real estate agency",
    "navHome": "Home",
    "navListings": "Portfolio",
    "navServices": "Services",
    "navBlog": "Market Intelligence",
    "navConsultation": "Free Consultation",
    "navContact": "Office & Contacts",
    "heroTitle": "Your Secured Gateway to the Perfect Home",
    "heroSubtitle": "With over 18 years of exceptional experience and more than 1000 successfully closed deals, BellEstateGroup guarantees your complete peace of mind, full legal security, and absolute professionalism.",
    "searchPlaceholder": "Search by neighborhood, city, or feature...",
    "filterType": "Property Type",
    "filterCity": "Location/City",
    "allTypes": "All Types",
    "allCities": "All Cities",
    "priceRange": "Max Budget",
    "btnSearch": "Search Properties",
    "house": "Family Country House",
    "villa": "Luxury Villa",
    "apartment": "Aristocratic Loft",
    "penthouse": "Luxury Penthouse",
    "sofia": "Sofia",
    "varna": "Varna",
    "plovdiv": "Plovdiv",
    "burgas": "Burgas",
    "bansko": "Bansko",
    "sqmLabel": "sq.m.",
    "roomsLabel": "rooms",
    "bathroomsLabel": "baths",
    "yearLabel": "built",
    "priceLabel": "Price:",
    "viewDetails": "View Details",
    "closeBtn": "Close",
    "featuresTitle": "Amenities & Technical Systems",
    "descriptionTitle": "Property Description",
    "specificationsTitle": "Building Specifications",
    "inquiryTitle": "Submit an inquiry regarding this property",
    "trustTitle": "Trust Is The Foundation Of Everything We Build",
    "trustSubtitle": "We do not simply broker bricks and concrete. We secure your family investment with absolute legal protection.",
    "value1Title": "100% Legal Guarantee",
    "value1Desc": "Every luxury property passed to our catalog undergoes rigorous multi-decade audit by in-house lawyers specializing only in national property registries.",
    "value2Title": "Radical Transparency",
    "value2Desc": "No surprise clauses, shadow fees, or inflated margins. Direct negotiations with real estate owners are conducted in honest English and Bulgarian.",
    "value3Title": "Architectural Rigor",
    "value3Desc": "We inspect thermal insulation, energy efficiency, engineering, and structures using licensed architects to ensure deep peace of mind.",
    "value4Title": "Absolute Confidentiality",
    "value4Desc": "We provide highly discreet handling of assets, structured private acquisitions, and tailor transaction logistics to your financial layout.",
    "stat1No": "18+",
    "stat1Lb": "Years Masterclasses in Bulgaria",
    "stat2No": "1000+",
    "stat2Lb": "Total Realized Deal Volume",
    "stat3No": "100%",
    "stat3Lb": "Undisputed Litigations-Free Records",
    "stat4No": "4.9/5",
    "stat4Lb": "Elite Client Trust Score",
    "sectionFeatured": "Featured Legacy Estates",
    "sectionFeaturedSub": "Carefully curated ultra-premium homes, fully certified and built to unmatched standards in Bulgaria.",
    "sectionBlog": "Market Intelligence & Advice",
    "sectionBlogSub": "Professional studies, structural guidelines, and regulatory advice to build your reliable Bulgarian portfolio.",
    "sectionConsultation": "Schedule a Private Consultation",
    "sectionConsultationSub": "Reserve an exclusive time slot. Our elite transactions manager will contact you to structure and plan your acquisition.",
    "sectionContact": "Contact Our Directors",
    "sectionContactSub": "Visit our flagship main office in Plovdiv or submit a secure online request.",
    "bookingFormName": "Your Full Name",
    "bookingFormEmail": "Email Address",
    "bookingFormPhone": "Phone Number",
    "bookingFormNotes": "Additional details (target budget, specific location...)",
    "bookingFormType": "Consultation Domain",
    "bookingTypeBuy": "Acquisition of Premium Real Estate",
    "bookingTypeSell": "Selling Strategic Personal Assets",
    "bookingTypeLegal": "Legal Auditing & Property Verification",
    "bookingTypeInvestment": "Eco-Luxury & Solar Passive Development",
    "bookingTypeOther": "Other Topic / Custom Inquiry",
    "bookingCalendarTitle": "Select Date & Available Time Slot",
    "bookingBtn": "Confirm Consultation Slot",
    "bookingSuccess": "Thank you! Your private consultation has been locked. An advisory manager will ring you shortly to coordinate.",
    "contactName": "Your Name",
    "contactEmail": "Your Personal Email",
    "contactPhone": "Contact Phone Number",
    "contactMessage": "Message (Briefly describe your requirements)",
    "contactSendBtn": "Send Secure Message",
    "contactSuccess": "Your message has been processed successfully! Our principal partners will review your request and answer within 2 business hours.",
    "contactOfficeTitle": "Our Main Headquarters",
    "contactAddress": "18 Dame Gruev St, Plovdiv, Bulgaria",
    "contactWorktime": "Working Hours: Mon - Fri: 08:30 - 18:00 | Sat: 10:00 - 17:00 | Sun: urgent cases",
    "contactPhoneVal": "032260510, 0898573681, 0889461275",
    "contactEmailVal": "estate_07@abv.bg",
    "followUs": "Connect with us on luxury platforms",
    "portfolioTitle": "Premium Real Estate Portfolio",
    "portfolioSubtitle": "Find your family estate or secure high-yield asset within our hand-picked and fully audited collection.",
    "sortBy": "Sort By",
    "sortPriceAsc": "Price: Low to High",
    "sortPriceDesc": "Price: High to Low",
    "sortSqmAsc": "Area: Small to Large",
    "sortSqmDesc": "Area: Large to Small",
    "noResults": "No properties found matching your criteria. Please adjust your filters and try again.",
    "resetFilters": "Reset Search Filters",
    "readPost": "Read Full Article",
    "backToBlog": "Back to Market Intelligence",
    "footerRights": "All rights reserved. Bell Estate Group.",
    "footerLegalInfo": "Bell Estate Group is a licensed and certified real estate broker holding full BS EN 15733 professional credentials.",
    "footerQuickLinks": "Quick Access"
  }
};
